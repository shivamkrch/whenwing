<?php 
//echo '<script src="/scripts/script-min.js" type="text/javascript"></script>';
echo '<script src="/scripts/jquery-3.3.1.min.js" type="text/javascript"></script>';
echo '  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
';
echo '<script src="/scripts/bootstrap.min.js" type="text/javascript"></script>';
echo '<script src="/scripts/owl.carousel.min.js" type="text/javascript"></script>';
echo '<script src="/scripts/script.js" type="text/javascript"></script>';
?>