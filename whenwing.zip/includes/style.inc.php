<link rel="stylesheet" href="/styles/css/owl.carousel.min.css">
<link rel="stylesheet" href="/styles/css/owl.theme.default.min.css">
<?php
$curtime = time();
echo '<link href="/styles/css/stylesheet.css?v='.$curtime.'" type="text/css" rel="stylesheet">';
echo '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
';
echo '<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.1/css/all.css" integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">';
?>