<?php
return [
    'root' => $_SERVER['DOCUMENT_ROOT'],
    'pages' => $_SERVER['DOCUMENT_ROOT'].'/resources/pages'
];   
?>