<section id="advertisement">
<div class="container">
            <div class="carousel-wrap-1">
                <div id="oc-1" class="owl-carousel">
                    <div class="item">
                        <img src="/images/ad-images/carpainter.jpg">
                    </div>
                    <div class="item">
                        <img src="/images/ad-images/service.jpeg">
                    </div>
                </div>
            </div>
        </div>
</section>