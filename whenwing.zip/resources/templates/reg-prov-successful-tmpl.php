<section id="reg-successful">
    <h1>Registration Successful.</h1>
    <p>Thank you for registring with us. </p>
    <p>We will contact you soon. </p>
</section>