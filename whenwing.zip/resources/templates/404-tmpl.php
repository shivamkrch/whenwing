<section id="page-not-found">
    <h1>404</h1>
    <p>Page Not Found!!</p>
</section>