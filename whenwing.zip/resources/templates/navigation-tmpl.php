<section id="nav-menu">
	<form action="/service-providers/" method="post" id="order-type-form">
		<nav>
			<ul>
				<li>
					<a href="#">Home Services</a>
					<ul>
						<li>
							<a href="#">Carpainter</a>
							<ul>
								<li>
									<a href="#">Door</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
										<li>
											<a href="#" class="menu-service">Helper</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Window</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
										<li>
											<a href="#" class="menu-service">Helper</a>
										</li>

									</ul>
								</li>
								<li>
									<a href="#">Almirah</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
										<li>
											<a href="#" class="menu-service">Helper</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Sofa</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
										<li>
											<a href="#" class="menu-service">Helper</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Kitchen</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li><li>
											<a href="#" class="menu-service">Helper</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Bed</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li><li>
											<a href="#" class="menu-service">Helper</a>
										</li>

									</ul>
								</li>
								<li>
									<a href="#">Table</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
										<li>
											<a href="#" class="menu-service">Helper</a>
										</li>

									</ul>
								</li>
								<li>
									<a href="#">LCD set</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
										<li>
											<a href="#" class="menu-service">Helper</a>
										</li>

									</ul>
								</li>
								<li>
									<a href="#">Others</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
										<li>
											<a href="#" class="menu-service">Helper</a>
										</li>

									</ul>
								</li>

							</ul>
						</li>
						<li>
							<a href="#">Painter</a>
							<ul>
								<li>
									<a href="#">Fresh</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
										<li>
											<a href="#" class="menu-service">Helper</a>
										</li>

									</ul>
								</li>
								<li>
									<a href="#">Repainting</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
										<li>
											<a href="#" class="menu-service">Helper</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Raj Mistri</a>
							<ul>
								<li>
									<a href="#">Fresh</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
										<li>
											<a href="#" class="menu-service">Helper</a>
										</li>

									</ul>
								</li>
								<li>
									<a href="#">Renovation</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
										<li>
											<a href="#" class="menu-service">Helper</a>
										</li>

									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Plumber</a>
							<ul>
								<li>
									<a href="#">Normal Plumbing Service</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Repair/Leakage</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Installation Services (eg: sinc, Toilet)</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>

									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Electrician</a>
							<ul>
								<li>
									<a href="#">Fitting/Installation</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Repair Service</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Wood Polisher</a>
							<ul>
								<li>
									<a href="#">Fresh</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Repair</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Glass men</a>
							<ul>
								<li>
									<a href="#">All type Glass Supplier</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Service/ Repair</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Architect</a>
							<ul>
								<li>
									<a href="#">Home</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Architect</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Office</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Architect</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Builder</a>
							<ul>
								<li>
									<a href="#">Home</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Architect</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Office</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Architect</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Interior Designer</a>
							<ul>
							<li>
								<a href="#">Home</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Architect</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Office</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Architect</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Internet Provider</a>
							<ul>
								<li>
									<a href="#">Broadband</a>
									<ul>
										<li>
											<a href="#">Reliance Jio</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Vodafone</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Idea</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Reliance</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Tata</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Aircel</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Others</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Data Card</a>
									<ul>
										<li>
											<a href="#">Reliance Jio</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Vodafone</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Idea</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Reliance</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Tata</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Aircel</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Others</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Wifi</a>
									<ul>
										<li>
											<a href="#">Reliance Jio</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Vodafone</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Idea</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Reliance</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Tata</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Aircel</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Others</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Wimax</a>
									<ul>
										<li>
											<a href="#">Reliance Jio</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Vodafone</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Idea</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Reliance</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Tata</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Aircel</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Others</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Prepaid</a>
												</li>
												<li>
													<a href="#" class="menu-service">Postpaid</a>
												</li>
											</ul>
										</li>
									</ul>
								</li>
								
								
							</ul>
						</li>
						<li>
							<a href="#">Washermen</a>
							<ul>
								<li>
									<a href="#">Washing</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Pressing</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Drycleaning</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Visitor</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
								
							</ul>
						</li>
						<li>
							<a href="#">Pundit/Puja</a>
							<ul>
								<li>
									<a href="#" class="menu-service">Naamkaran</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Pundit</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Katha</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Pundit</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Gharpravesh</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Pundit</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Jaagaran</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Pundit</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Others</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Pundit</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Photographer</a>
							<ul>
								<li>
									<a href="#">Wedding Photographer</a>
									<ul>
										<li>
											<a href="#">Digial</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Album</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Digial</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li> 
										<li>
											<a href="#">Digial Copy + Album</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Event Photographer</a>
									<ul>
										<li>
											<a href="#">Digial</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Album</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Digial</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li> 
										<li>
											<a href="#">Digial Copy + Album</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Kids Photographer</a>
									<ul>
										<li>
											<a href="#">Digial</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Album</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Digial</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li> 
										<li>
											<a href="#">Digial Copy + Album</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Commercial Photographer</a>
									<ul>
										<li>
											<a href="#">Digial</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Album</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Digial</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li> 
										<li>
											<a href="#">Digial Copy + Album</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Fasion Photographer</a>
									<ul>
										<li>
											<a href="#">Digial</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Album</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Digial</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li> 
										<li>
											<a href="#">Digial Copy + Album</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">others</a>
									<ul>
										<li>
											<a href="#">Digial</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Album</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Digial</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li> 
										<li>
											<a href="#">Digial Copy + Album</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Web Designer &amp; Developer</a>
							<ul>
							<li>
									<a href="#">New Website</a>
									<ul>
										<li>
											<a href="#">Business</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Personal</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Ecommerce</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li> 
										<li>
											<a href="#">Blog</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li> 
										<li>
											<a href="#">Elearning</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li> 
										<li>
											<a href="#">Others</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li> 
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Concrete Provider</a>
							<ul>
								<li>
									<a href="#" class="menu-service">Advisor (Free)</a>
								</li>
								<li>
									<a href="#" class="menu-service">Provider</a>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">CCTV Camera &amp; Installation</a>
							<ul>
								<li>
									<a href="#">Installation</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Repair and Part Replacement</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Others</a>
							<ul>
								<li>
									<a href="#" class="menu-service">Advisor (Free)</a>
								</li>
								<li>
									<a href="#" class="menu-service">Visitor</a>
								</li>
								<li>
									<a href="#" class="menu-service">Provider</a>
								</li>
							</ul>
						</li>

					</ul>
				</li>
				<li>
					<a href="#">Appliance Repair</a>
					<ul>
						<li>
							<a href="#">AC Service, Repair &amp; Installation</a>
							<ul>
								<li>
									<a href="#">Repair</a>
									<ul>
										<li>
											<a href="#" >Window AC</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Split AC</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Installation</a>
									<ul>
										<li>
											<a href="#" >Window AC</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Split AC</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Un installation</a>
									<ul>
										<li>
											<a href="#" >Window AC</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Split AC</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Gas Filling</a>
									<ul>
										<li>
											<a href="#" >Window AC</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#" >Split AC</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
									</ul>
								</li>

							</ul>
						</li>
						<li>
							<a href="#">Refrigerator Repair</a>
							<ul>
								<li>
									<a href="#" >Repair/Replacement</a>
									<ul>
										<li>
											<a href="#">One door</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Two door</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Three door</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Others</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Maintenance/Fixing</a>
									<ul>
										<li>
											<a href="#">One door</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Two door</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Three door</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="#">Others</a>
											<ul>
												<li>
													<a href="#" class="menu-service">Advisor (Free)</a>
												</li>
												<li>
													<a href="#" class="menu-service">Provider</a>
												</li>
											</ul>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Washing Machine Repair</a>
							<ul>
								<li>
									<a href="#">Repair/Part Replacement</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Maintenance/Fixing</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">RO or Water Purifier Repair</a>
							<ul>
								<li>
									<a href="#">Repair/Part Replacement</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Maintenance/Fixing</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Microwave Repair</a>
							<ul>
								<li>
									<a href="#">Repair/Part Replacement</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Maintenance/Fixing</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">TV Repair &amp; Installation</a>
							<ul>
								<li>
									<a href="#">Repair/Part Replacement</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Installation</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Air Cooler Repair</a>
							<ul>
								<li>
									<a href="#">Repair/Part Replacement</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Maintenance/Fixing</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Geyser/Water Heater Repair</a>
							<ul>
								<li>
									<a href="#">Repair/Part Replacement</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Maintenance/Fixing</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Computer Repair</a>
							<ul>
								<li>
									<a href="#">Repair/Part Replacement</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Maintenance/Fixing</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#">Mobile Repair</a>
							<ul>
								<li>
									<a href="#">Repair/Part Replacement</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Software Services</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Advisor (Free)</a>
										</li>
										<li>
											<a href="#" class="menu-service">Provider</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
					</ul>
				</li>
				<li>
					<a href="#">Transport</a>
					<ul>
						
						<li>
							<a href="#">Transport Services</a>
							<ul>
								<li>
									<a href="#">Business</a>
									<ul>
										<li>
											<a href="#" class="menu-service1">Domestic Packers &amp; Movers</a>
										</li>
										<li>
											<a href="#" class="menu-service1">Industrial Packers &amp; Movers</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Personal</a>
									<ul>
										<li>
											<a href="#" class="menu-service1">Domestic Packers &amp; Movers</a>
										</li>
										<li>
											<a href="#" class="menu-service1">Industrial Packers &amp; Movers</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>

						<li>
							<a href="#">Travel</a>
							<ul>
								<li>
									<a href="#">Local</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Auto</a>
										</li>
										<li>
											<a href="#" class="menu-service">Van</a>
										</li>
										<li>
											<a href="#" class="menu-service">Bus</a>
										</li>
										<li>
											<a href="#" class="menu-service">Car</a>
										</li>
										<li>
											<a href="#" class="menu-service">Tempo</a>
										</li>
										<li>
											<a href="#" class="menu-service">Truck</a>
										</li>
										<li>
											<a href="#" class="menu-service">e-Rickshaw</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#" >Outstation</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Bus</a>
										</li>
										<li>
											<a href="#" class="menu-service">Car</a>
										</li>
										<li>
											<a href="#" class="menu-service">Tempo</a>
										</li>
										<li>
											<a href="#" class="menu-service">Truck</a>
										</li>
										<li>
											<a href="#" class="menu-service">Van</a>
										</li>
									</ul>
								</li>
							</ul>

						</li>


					</ul>
				</li>
				<li>
					<a href="#">Personal Service</a>
					<ul>
						<li>
							<a href="#" class="menu-service1">Cook</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Driver</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Yoga Trainer</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Dietician</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Naukar</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Security Guard</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Dancer</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Gardener</a>
						</li>

					</ul>
				</li>
				<li>
					<a href="#">Shop</a>
					<ul>
						<li>
							<a href="#" class="menu-service1">Furniture</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Hardware</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Moulding</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Footwear</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Restaurants</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Mobile</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Stationary</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Gift Shop</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Institutes</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Academy</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Ply &amp; Wood</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Clothes</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Beauty Parlour</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Salon</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Spa</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Gym</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Sweets Corner</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Photoshop</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Pharmacy</a>
						</li>
					</ul>
				</li>
				<li>
					<a href="#">Showroom</a>
					<ul>
						<li>
							<a href="#" class="menu-service1">Car Showroom</a>
							<ul>
								<li>
									<a href="#" class="menu-service1">Tata Motors</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Maruti Suzuki</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Hyundai</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Toyota</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Mahindra</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Honda</a>
								</li>
								<li>
									<a href="#" class="menu-service1">volkswagen</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Ford</a>
								</li>
								<li>
									<a href="#" class="menu-service1">BMW</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Audi</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Mercedes</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Skoda</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Datsun</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Volvo</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Nissan</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Fiat</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Land Rover</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Ferrari</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Maserati</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Force</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Lexus</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Aston Martin</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Premier</a>
								</li>
								<li>
									<a href="#" class="menu-service1">DC</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Force Motors</a>
								</li>
								<li>
									<a href="#" class="menu-service1">ISUZU</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Bentley</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Bugati</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Porsche</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Rolls Royce</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Mini</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Lamborghini</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Jaguar</a>
								</li>
								
							</ul>

						</li>
						<li>
							<a href="#" class="menu-service1">Bike Showroom</a>
							<ul>
								<li>
									<a href="#" class="menu-service1">Bajaj</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Hero</a>
								</li>
								<li>
									<a href="#" class="menu-service1">TVS</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Royal Enfield</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Yamaha</a>
								</li>
								<li>
									<a href="#" class="menu-service1">KTM</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Hero Electric</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Mahindra</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Suzuki</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Harley</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Vespa</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Kawasaki</a>
								</li>
								<li>
									<a href="#" class="menu-service1">Lahia</a>
								</li>
							</ul>
						</li>
						<li>
							<a href="#" class="menu-service1">Scooty &amp; Scooter Showroom</a>
						</li>
						<li>
							<a href="#">Clothes</a>
							<ul>
								<li>
									<a href="#">Men</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Footwear</a>	
										</li>
										<li>
											<a href="#" class="menu-service">Men's Grooming</a>	
										</li>
										<li>
											<a href="#" class="menu-service">Topwear</a>	
										</li>
										<li>
											<a href="#" class="menu-service">Bottom Wear</a>	
										</li>
										<li>
											<a href="#" class="menu-service">Sports wear</a>	
										</li>
										<li>
											<a href="#" class="menu-service">inner wear &amp; sleepwear</a>	
										</li>
										<li>
											<a href="#" class="menu-service">Ties, Socks, Caps &amp; more</a>	
										</li>
										<li>
											<a href="#" class="menu-service">Kurta, Pyjama &amp; more</a>	
										</li>
										<li>
											<a href="#" class="menu-service">Winter wear</a>	
										</li>
										<li>
											<a href="#" class="menu-service">Fabrics</a>	
										</li>
										<li>
											<a href="#" class="menu-service">Watches</a>	
										</li>
										<li>
											<a href="#" class="menu-service">Accessories</a>	
										</li>
										<li>
											<a href="#" class="menu-service">Sports and fitness</a>	
										</li>
										<li>
											<a href="#" class="menu-service">Smart Watches</a>	
										</li>
										<li>
											<a href="#" class="menu-service">Smart Bands</a>	
										</li>
										<li>
											<a href="#" class="menu-service">Personal Care</a>	
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Women</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Western Wear</a>
										</li>
										<li>
											<a href="#" class="menu-service">Lingerie & Sleepwear</a>
										</li>
										<li>
											<a href="#" class="menu-service">Sports Wear</a>
										</li>
										<li>
											<a href="#" class="menu-service">Swin & Beachwear</a>
										</li>
										<li>
											<a href="#" class="menu-service">Ethnic Wear</a>
										</li>
										<li>
											<a href="#" class="menu-service">Footwear</a>
										</li>
										<li>
											<a href="#" class="menu-service">Watches</a>
										</li>
										<li>
											<a href="#" class="menu-service">Personal Care</a>
										</li>
										<li>
											<a href="#" class="menu-service">Beauty & Grooming</a>
										</li>
										<li>
											<a href="#" class="menu-service">Jewellery</a>
										</li>
										<li>
											<a href="#" class="menu-service">Accessories</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#">Kids</a>
									<ul>
										<li>
											<a href="#" class="menu-service">Boys Clothing</a>
										</li>
										<li>
											<a href="#" class="menu-service">Girl Clothing</a>
										</li>
										<li>
											<a href="#" class="menu-service">Baby Girl Clothing</a>
										</li>
										<li>
											<a href="#" class="menu-service">Baby Boy Clothing</a>
										</li>
										<li>
											<a href="#" class="menu-service">Boys Footwear</a>
										</li>
										<li>
											<a href="#" class="menu-service">Girls Footwear</a>
										</li>
										<li>
											<a href="#" class="menu-service">Baby Footwear</a>
										</li>
										<li>
											<a href="#" class="menu-service">Toys</a>
										</li>
										<li>
											<a href="#" class="menu-service">BabyCare</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="#" class="menu-service1">Watch</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Mobile</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Electronics</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Ac &amp; Cooler</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Furniture</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Laptop and Computer</a>
						</li>
						<li>
							<a href="#" class="menu-service1">jewellery</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Bag &amp; Suitcase</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Gifts</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Footwear</a>
						</li>

					</ul>
				</li>
				<li>
					<a href="#">Education</a>
					<ul>
						<li>
							<a href="#" class="menu-service1">IES</a>
						</li>
						<li>
							<a href="#">IAS</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Gate</a>
						</li>
						<li>
							<a href="#" class="menu-service1">CAT</a>
						</li>
						<li>
							<a href="#" class="menu-service1">SSC</a>
						</li>
						<li>
							<a href="#" class="menu-service1">JE</a>
						</li>
						<li>
							<a href="#" class="menu-service1">CGL</a>
						</li>
						<li>
							<a href="#">CHSL</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Army</a>
						</li>
						<li>
							<a href="#" class="menu-service1">CDS</a>
						</li>
						<li>
							<a href="#" class="menu-service1">XAT</a>
						</li>
						<li>
							<a href="#">IIT-JEE</a>
						</li>
						<li>
							<a href="#" class="menu-service1">CLAT</a>
						</li>
						<li>
							<a href="#" class="menu-service1">MAT</a>
						</li>
						<li>
							<a href="#" class="menu-service1">CLAT PG</a>
						</li>
						<li>
							<a href="#" class="menu-service1">AILET PG</a>
						</li>
						<li>
							<a href="#">CLAT</a>
						</li>
						<li>
							<a href="#" class="menu-service1">AILET</a>
						</li>
						<li>
							<a href="#" class="menu-service1">DU LLB</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Neet PG</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Neet UG</a>
						</li>
						<li>
							<a href="#" class="menu-service1">AIIMS MBBS</a>
						</li>
						<li>
							<a href="#" class="menu-service1">AIIMS PG</a>
						</li>
						<li>
							<a href="#" class="menu-service1">JIPMER ME</a>
						</li>
						<li>
							<a href="#" class="menu-service1">RBI Assistant</a>
						</li>
						<li>
							<a href="#" class="menu-service1">IBS PO</a>
						</li>
						<li>
							<a href="#" class="menu-service1">NDA</a>
						</li>
						<li>
							<a href="#" class="menu-service1">SBI PO</a>
						</li>
						<li>
							<a href="#" class="menu-service1">C, C++</a>
						</li>
						<li>
							<a href="#" class="menu-service1">JAVA</a>
						</li>
					</ul>
				</li>
				<li>
					<a href="#">Wedding/Party</a>
					<ul class="occ-indent">
						<li>
							<a href="#" class="menu-service1">DJ</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Wedding Planner</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Party Planner</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Event Photographer</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Bridal Make-up Artist</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Hair Style &amp; Make-up</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Party Caterers</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Wedding Caterers</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Wedding Florist &amp; Decoraters</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Farm House</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Halwai</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Tent &amp; Decorators</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Mehandi Artist</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Band</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Ghori and Baggi</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Flower, Jhumar</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Light set</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Palki, Aatish Baazi and more</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Waiter Services</a>
						</li>
						<li>
							<a href="#" class="menu-service1">Video Camereaman</a>
						</li>
						<li>
							<a href="#" class="menu-service1">jewellery</a>
						</li>

					</ul>
				</li>
			</ul>
		</nav>
		<input type="hidden" name="ord-type1" id="ord-t1" value="">
		<input type="hidden" name="ord-type2" id="ord-t2" value="">
		<input type="hidden" name="ord-type3" id="ord-t3" value="">
		<input type="hidden" name="ord-type4" id="ord-t4" value="">
	</form>
</section>
<div class="space-correction"></div>
