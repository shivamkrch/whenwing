<section class="form-sec" >
    <form id="order-form" action="/handlers/formhandle/order/" method="POST">
        <div>
            <p class="form-title">Page Title</p>
            <span class="input-title">Type of Service</span>
            <select class="inp-select" id="profession-service" name="order-type1">
                <option>Choose Service</option>
            </select>
            <span class="input-title">Profession</span>
            <select class="inp-select" id="profession-name" name="order-type2">
                <option>Choose Profession</option>
            </select>
            <span class="input-title">Work Type</span>
            <select class="inp-select" id="profession-type-sel" name="order-type3">
                <option>Choose Type of Work</option>
            </select>
            <span class="input-title">Designation</span>
            <select class="inp-select" id="profession-role-sel" name="order-type4">
                <option>Choose Designation</option>
            </select>

            <div class="btn order-btn">Submit</div>
        </div>
    </form>
</section>




<!-- <section class="form-sec" >
    <form id="order-form" action="/handlers/formhandle/order/" method="POST">
        <div>
            <p class="form-title">Page Title</p>
            <span class="input-title">Type of Service</span>
            <select class="inp-select" id="profession-service" name="order-type1">
                <option>Choose Service</option>
                <option>Home Services</option>
                <option>Appliance Repair</option>
                <option>Transport &amp; Travel</option>
                <option>Showroom</option>
                <option>Occasion</option>
            </select>
            <span class="input-title">Profession</span>
            <select class="inp-select" id="profession-name" name="order-type2">
                <option>Choose Profession</option>
                <option class="or-opt-11">Carpainter</option>
                <option class="or-opt-11">Painter</option>
                <option class="or-opt-11">Rajmistri</option>
                <option class="or-opt-11">Plumber</option>
                <option class="or-opt-11">Electrician</option>
                <option class="or-opt-11">Polisher</option>
                <option class="or-opt-11">Glassmen</option>
                <option class="or-opt-11">Architect</option>
                <option class="or-opt-11">Builder</option>
                <option class="or-opt-11">Pandit/ Puja</option>
                <option class="or-opt-12">AC Service, Repair &amp; Installation</option>
                <option class="or-opt-12">Refrigerator Repair</option>
                <option class="or-opt-12">Washing Machine Repair</option>
                <option class="or-opt-12">RO or Water Purifier Repair</option>
                <option class="or-opt-12">Microwave Repair</option>
                <option class="or-opt-12">TV Repair &amp; Installation</option>
                <option class="or-opt-12">Air Cooler Repair</option>
                <option class="or-opt-12">Geyser/Water Heater Repair</option>
                <option class="or-opt-12">Computer Repair</option>
                <option class="or-opt-12">Mobile Repair</option>
                <option class="or-opt-12">CCTV Camera &amp; Installation</option>
                <option class="or-opt-13">Transport</option>
                <option class="or-opt-13">Travel</option>
                <option class="or-opt-14">Car Showroom</option>
                <option class="or-opt-14">Bike Showroom</option>
                <option class="or-opt-15">Wedding</option>
                <option class="or-opt-15">Birthday</option>
                <option class="or-opt-15">Anniversary</option>
                <option class="or-opt-15">Others</option>1
            </select>
            <span class="input-title">Work Type</span>
            <select class="inp-select" id="profession-type-sel" name="order-type3">
                <option>Choose Type of Work</option>
            </select>
            <span class="input-title">Designation</span>
            <select class="inp-select" id="profession-role-sel" name="order-type4">
                <option>Choose Designation</option>
            </select>

            <div class="btn order-btn">Submit</div>
        </div>
    </form>
</section> -->
