<section class="form-sec">
    <div class="category-prov">
        <span class="form-title">Select a Category for Registration</span>
        <a href="/register-service">Home Services</a>
        <a href="/register-service"> Repair </a>
        <a href="/register-service">Transport  </a>
        <a href="/register-service">Personal Service  </a>
        <a href="/register-shop">Looking Shop  </a>
        <a href="/register-shop">Showroom  </a>
        <a href="/register-service">Rojgar  </a>
        <a href="/register-service">Occasion </a>
    </div>
</section>
