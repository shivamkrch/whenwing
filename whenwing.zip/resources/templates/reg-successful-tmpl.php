<section id="reg-successful">
    <h1>Registration Successful</h1>
    <p>Go to <a href="/login">login</a> Page </p>
</section>