<header>
        <div class="logo-and-name">
            <a href="/">
                <img src="/images/icons/logo.png" class="site-logo">
                <span class="site-name">WhenWing</span>
            </a>
        </div>
        <div class="search-div">
            <input type="text" id="search-input" placeholder="Search for Service, Shop, Rojgaar ">
            <span class="search-icon"></span>
            <div id="search-result"></div>
        </div>
        <div class="header-menu">
            <a href="/become-a-provider">Become a Provider</a>
            <a href="/login">Login </a><span class="hidden">|</span>
            <a href="/sign-up">Sign Up</a>
        </div>
</header>
<div id="hamburger-icon">
    <span></span>
    <span></span>
    <span></span>
    <span></span>
</div>
